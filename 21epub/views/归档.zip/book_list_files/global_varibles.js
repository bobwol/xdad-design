/* define global varibles */
var is_server=true; //define if the server is on or offline
var edit_changed=false; //define to prejudge the change event happen or not 
var iGlobalDict=null;//定义全局字典
var json_timeout=false;//定义json读取的时间