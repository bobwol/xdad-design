/* for global functions */
$(function(){
	$('.related-mod').hide();
})

function init_global_related_mod_hide(){
	$('.related-mod').hide();
}