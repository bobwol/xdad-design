/* The model for dict */
var iDictModel=iComacBaseModel.extend({
	defaults:{
	},
	setparentdiv:function(type){
		//no parentdiv needed;
	},
	setcollection:function(type){
		//this.icollection=new iProgressCollection();
	},
	setview:function(type){
		//this.iview=new iProgressView({model:this});
	}
})

//iGlobalDict=new iDictModel({id:'iDict'});
