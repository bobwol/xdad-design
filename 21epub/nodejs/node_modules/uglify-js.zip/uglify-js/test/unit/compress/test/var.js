// var declarations after each other should be combined
var a = 1;
var b = 2;