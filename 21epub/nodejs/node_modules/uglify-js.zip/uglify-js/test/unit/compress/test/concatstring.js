var a = a + "a" + "b" + 1 + c;
var b = a + "c" + "ds" + 123 + c;
var c = a + "c" + 123 + d + "ds" + c;